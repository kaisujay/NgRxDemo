import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Country } from '@shared/models/countries.model';
import { UserRoleModel } from '../models/create-new-user.model';
import { UserPoolLockedModel } from '../models/user-pool-locked.model';
import { UserPoolResponseItemModel } from '../models/user-pool-response.model';

export class UserPoolService {
  public static getStatusOptions(locked: UserPoolLockedModel[]): SelectOptions[] {
    return locked.map(status => ({
      value: status.Code,
      label: status.Desc
    }));
  }

  public static getCountryOptions(country: Country[]): { label: string; value: string }[] {
    if (!country || !country.length) {
      return [];
    }

    return country.map(countrys => {
      return {
        label: countrys.countryName,
        value: countrys.countryName
      };
    });
  }

  public static getUserRoleOptions(userRole: UserRoleModel[]): { label: string; value: string }[] {
    if (!userRole || !userRole.length) {
      return [];
    }

    return userRole.map(userRoles => {
      return {
        label: userRoles.Desc,
        value: userRoles.Code
      };
    });
  }

  public static searchUserPoolService(
    userPool: UserPoolResponseItemModel[],
    filter: string
  ): UserPoolResponseItemModel[] {
    return filter !== ''
      ? userPool.filter(userPool => {
          const searchInProp = (prop: string) =>
            userPool[prop] && userPool[prop].toString().toLowerCase().includes(filter.toLowerCase());

          return (
            searchInProp('Email') ||
            searchInProp('FirstName') ||
            searchInProp('LastName') ||
            searchInProp('Status') ||
            searchInProp('LastLogin')
          );
        })
      : userPool;
  }
}
