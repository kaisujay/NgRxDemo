import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import * as dayjs from 'dayjs';
import { saveAs } from 'file-saver';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import * as XLSX from 'xlsx';
import { UserPoolResponseItemModel } from '../models/user-pool-response.model';

@Injectable()
export class UserPoolExportToExcelService {
  public constructor(
    private http: HttpClient,
    private kendoAdapterService: KendoAdapterService
  ) {}

  public export(url: string): Observable<any> {
    return this.kendoAdapterService.getAllWithId(url).pipe(
      map(response => {
        response.rowData = response.rowData.map((userPool: UserPoolResponseItemModel) => {
          return {
            Email: userPool.Email,
            'First Name': userPool.FirstName,
            'Last Name': userPool.LastName,
            Status: userPool.Status,
            'Last Login': userPool.LastLoginDate ? dayjs(userPool.LastLoginDate).format() : '-',
            'Locked?': userPool.Lockout
          };
        });

        const wb = XLSX.utils.book_new();
        const ws = XLSX.utils.json_to_sheet(response.rowData);
        ws['!cols'] = [
          { wch: 25 },
          { wch: 25 },
          { wch: 30 },
          { wch: 10 },
          { wch: 25 },
          { wch: 25 },
          { wch: 25 },
          { wch: 10 },
          { wch: 25 },
          { wch: 25 }
        ];

        XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');

        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });

        const blob = new Blob([excelBuffer], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
        });
        saveAs(blob, `users`);
      })
    );
  }
}
