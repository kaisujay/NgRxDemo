import { CheckboxRendererComponent } from '@shared/components/ag-grid-templates/lockout.template/checkbox-renderer.component';
import { CustomLoadingCellRendererComponent } from '@shared/components/loading-cell-renderer/loading-cell-renderer.component';
import { GridOptions } from 'ag-grid-community';
import { EmailFirstLastNameComponent } from '../components/ag-grid-template/email-first-last-name/email-first-last-name.component';

export const USER_POOL_GRID_OPTIONS: GridOptions = {
  columnDefs: [
    {
      headerName: 'Email',
      tooltipField: 'Email',
      field: 'Email',
      sort: 'asc',
      minWidth: 200,
      cellRendererFramework: EmailFirstLastNameComponent
    },
    {
      headerName: 'First Name',
      field: 'FirstName',
      tooltipField: 'FirstName',
      minWidth: 180,
      cellRendererFramework: EmailFirstLastNameComponent
    },
    {
      headerName: 'Last Name',
      field: 'LastName',
      tooltipField: 'LastName',
      minWidth: 180,
      cellRendererFramework: EmailFirstLastNameComponent
    },
    {
      headerName: 'Status',
      tooltipField: 'Status',
      field: 'Status',
      minWidth: 100
    },
    {
      headerName: 'Last Login',
      tooltipField: 'LastLoginDate',
      field: 'LastLoginDate',
      minWidth: 250
    },
    {
      headerName: 'Locked?',
      field: 'Lockout',
      cellRenderer: 'checkboxRenderer',
      minWidth: 80,
      sortable: false
    }
  ],
  frameworkComponents: {
    checkboxRenderer: CheckboxRendererComponent
  },
  defaultColDef: {
    flex: 1,
    minWidth: 90,
    resizable: true,
    sortable: true
  },
  rowModelType: 'serverSide',
  serverSideStoreType: 'partial',
  pagination: true,
  paginationPageSize: 50,
  cacheBlockSize: 50,
  animateRows: true,
  loadingCellRendererFramework: CustomLoadingCellRendererComponent,
  suppressRowClickSelection: true,
  suppressCellSelection: true,
  suppressDragLeaveHidesColumns: true,
  suppressNoRowsOverlay: true,
  suppressLoadingOverlay: true,
  suppressContextMenu: true,
  suppressColumnMoveAnimation: true,
  enableCellTextSelection: true,
  suppressHorizontalScroll: false
};
