export interface UserPoolLockedModel {
  Code: string;
  Desc: string;
  CodeId: number;
  SortOrder: number;
}
