import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { KendoAdapterService } from '@shared/services/kendo-adapter.service';
import { catchError, forkJoin, map, of, switchMap } from 'rxjs';
import { UserPoolUserHttpService } from '../../services/user-pool.user.http.service';
import {
  LoadCountryAndUserRoleAction,
  LoadCountryAndUserRoleFailedAction,
  LoadCountryAndUserRoleSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class LoadCountryRoleUserPoolEffect {
  public constructor(
    private actions$: Actions,
    private kendoAdapterService: KendoAdapterService,
    private httpService: UserPoolUserHttpService
  ) {}
  public loadCountryRoleUserPoolEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.LoadCountryAndUserRole),
      switchMap((_action: LoadCountryAndUserRoleAction) =>
        forkJoin(this.httpService.getCountries(), this.httpService.getUserRoles()).pipe(
          map(([countries, userRoles]) => {
            return new LoadCountryAndUserRoleSuccessAction({
              countries,
              userRoles
            });
          }),
          catchError(_err => of(new LoadCountryAndUserRoleFailedAction()))
        )
      )
    )
  );
}
