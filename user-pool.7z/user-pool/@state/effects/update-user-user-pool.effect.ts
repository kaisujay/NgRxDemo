import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, map, of, switchMap } from 'rxjs';
import { UserPoolUserHttpService } from '../../services/user-pool.user.http.service';
import {
  SaveEditedUserAction,
  SaveEditedUserFailedAction,
  SaveEditedUserSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class UpdateUserEffect {
  public constructor(
    private actions$: Actions,
    private userPoolService: UserPoolUserHttpService,
    private store$: Store
  ) {}
  public updateUserEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.SaveEditedUser),
      switchMap((action: SaveEditedUserAction) => {
        return this.userPoolService.updateUser(action.containerId, action.userId, action.user).pipe(
          map(() => new SaveEditedUserSuccessAction()),
          catchError(err => of(new SaveEditedUserFailedAction(err)))
        );
      })
    )
  );
}
