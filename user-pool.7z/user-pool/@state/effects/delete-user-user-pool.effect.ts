import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Store } from '@ngrx/store';
import { catchError, map, of, switchMap } from 'rxjs';
import { UserPoolUserHttpService } from '../../services/user-pool.user.http.service';
import {
  SaveDeleteUserAction,
  SaveDeleteUserFailedAction,
  SaveDeleteUserSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class DeleteUserEffect {
  public constructor(
    private actions$: Actions,
    private userPoolService: UserPoolUserHttpService,
    private store$: Store
  ) {}
  public deleteUserEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.SaveDeleteUser),
      switchMap((action: SaveDeleteUserAction) => {
        return this.userPoolService.deleteUser(action.userId).pipe(
          map(() => new SaveDeleteUserSuccessAction()),
          catchError(() => of(new SaveDeleteUserFailedAction()))
        );
      })
    )
  );
}
