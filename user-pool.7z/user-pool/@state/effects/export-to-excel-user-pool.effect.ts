import { Injectable } from '@angular/core';
import { API } from '@core/constants/API';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, of, switchMap } from 'rxjs';

import { UserPoolExportToExcelService } from '../../services/user-pool.export-to-excel.service';
import {
  ExportToXLSXAction,
  ExportToXLSXFailedAction,
  ExportToXLSXSuccessAction,
  UserPoolActionTypes
} from '../actions/user-pool.action';

@Injectable()
export class ExportToXlsxUserPoolEffect {
  public constructor(
    private actions$: Actions,
    private exportToExcelService: UserPoolExportToExcelService
  ) {}
  public exportToXlsxEffect$ = createEffect(() =>
    this.actions$.pipe(
      ofType(UserPoolActionTypes.ExportToXLSX),
      switchMap((action: ExportToXLSXAction) =>
        this.exportToExcelService
          .export(API.userPool.getUsersforUserPool + '?containerId=' + action.containerId + '&')
          .pipe(
            map(_res => {
              return new ExportToXLSXSuccessAction();
            }),
            catchError(_err => of(new ExportToXLSXFailedAction()))
          )
      )
    )
  );
}
