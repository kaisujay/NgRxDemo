import { Component, DoCheck, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { SelectOptions } from '@ipreo/ngx-sprinkles';
import { Store, select } from '@ngrx/store';
import { Country } from '@shared/models/countries.model';
import { Observable, map } from 'rxjs';
import {
  ClearEditUserHttpErrorsAction,
  CloseModalsAction,
  DeleteUserAction,
  ResetPasswordAction,
  SaveEditedUserAction
} from '../../@state/actions/user-pool.action';
import { UserPoolState, getUserPoolState } from '../../@state/reducers/user-pool.reducer';
import {
  IndivisualUserModel,
  UpdateUserInUserPoolPayloadModel,
  UserRoleModel
} from '../../models/create-new-user.model';
import { UserPoolService } from '../../services/user-pool.service';

@Component({
  selector: 'app-edit-user',
  templateUrl: './edit-user.component.html',
  styleUrls: ['./edit-user.component.scss']
})
export class EditUserComponent implements OnInit, DoCheck {
  @Input() public Countries: Country[];
  @Input() public UserRoles: UserRoleModel[];
  @Output() public sendUserId: EventEmitter<string> = new EventEmitter();

  public userPoolState$: Observable<UserPoolState>;
  public isResetPasswordShown$: Observable<boolean>;
  public ContainerName: string;

  public editUserFormGroup: FormGroup;
  public initialUserModel: IndivisualUserModel;
  public shouldDisableButtons: boolean;
  public containerId: string;
  public userId: string;
  public rowVersion: number;
  public email: string;

  public updateUser: UpdateUserInUserPoolPayloadModel;

  public countryOptions: SelectOptions[];
  public userRolesOptions: SelectOptions[];

  public constructor(
    private formBuilder: FormBuilder,
    private store$: Store
  ) {}

  public ngDoCheck(): void {
    if (JSON.stringify(this.initialUserModel) === JSON.stringify(this.editUserFormGroup.value)) {
      this.shouldDisableButtons = false;
    } else {
      this.shouldDisableButtons = true;
    }
  }

  public ngOnInit(): void {
    this.setOptions();
    this.initForm();

    this.userPoolState$ = this.store$.pipe(select(getUserPoolState));
    this.store$.pipe(select(getUserPoolState)).subscribe(data => {
      this.ContainerName = data.loadContainer.container.Name;
      this.updateFormValue(data);
    });

    this.isResetPasswordShown$ = this.store$.pipe(
      select(getUserPoolState),
      map(state => state.editUser.isResetPasswordModalVisible)
    );
  }

  private initForm(): void {
    this.editUserFormGroup = this.formBuilder.group({
      Email: new FormControl('', [
        Validators.required,
        Validators.pattern(
          new RegExp(
            // eslint-disable-next-line no-useless-escape
            /^(([^<>()\\.,;:\s@\"]+(\.[^<>()\\.,;:\s@\"]+)*)|\".+\")@[a-zA-Z\-0-9]{2,}\.[a-zA-Z]{2,}(\.[a-zA-Z]{1,3})?$/
          )
        )
      ]),
      IpreoAccountId: new FormControl({ value: '', disabled: true }, []),
      FirstName: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      LastName: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      Title: new FormControl(''),
      Role: new FormControl(''),
      PhoneNumber: new FormControl('', [Validators.pattern('^[0-9]*$')]),
      City: new FormControl('', [Validators.required, Validators.pattern(/[\S]/)]),
      Country: new FormControl('', [Validators.required]),
      Status: new FormControl(''),
      IsContainerAdmin: new FormControl(''),
      IsExcludedFromMembershipAudit: new FormControl(''),
      ApiOnly: new FormControl(''),
      IsFixServiceAccount: new FormControl(''),
      IpreoAccountIntegrationRequired: new FormControl(''),
      ThinkFolioUserId: new FormControl('')
    });
  }

  public updateFormValue(data: UserPoolState) {
    if (data.loadUserDetails.user != null) {
      this.editUserFormGroup.controls['Email'].setValue(data.loadUserDetails.user.Email);
      this.editUserFormGroup.controls['IpreoAccountId'].setValue(data.loadUserDetails.user.IpreoAccountId);
      this.editUserFormGroup.controls['FirstName'].setValue(data.loadUserDetails.user.FirstName);
      this.editUserFormGroup.controls['LastName'].setValue(data.loadUserDetails.user.LastName);
      this.editUserFormGroup.controls['Title'].setValue(data.loadUserDetails.user.Title);
      this.editUserFormGroup.controls['Role'].setValue(data.loadUserDetails.user.Role);
      this.editUserFormGroup.controls['PhoneNumber'].setValue(data.loadUserDetails.user.PhoneNumber);
      this.editUserFormGroup.controls['City'].setValue(data.loadUserDetails.user.City);
      this.editUserFormGroup.controls['Country'].setValue(data.loadUserDetails.user.Country);
      this.editUserFormGroup.controls['Status'].setValue(data.loadUserDetails.user.Status);
      this.editUserFormGroup.controls['IsContainerAdmin'].setValue(data.loadUserDetails.user.Containers[0].IsAdmin);
      this.editUserFormGroup.controls['IsExcludedFromMembershipAudit'].setValue(
        data.loadUserDetails.user.Containers[0].IsExcludedFromMembershipAudit
      );
      this.editUserFormGroup.controls['ApiOnly'].setValue(data.loadUserDetails.user.ApiOnly);
      this.editUserFormGroup.controls['IsFixServiceAccount'].setValue(data.loadUserDetails.user.IsFixServiceAccount);
      this.editUserFormGroup.controls['IpreoAccountIntegrationRequired'].setValue(
        data.loadUserDetails.user.IpreoAccountIntegrationRequired
      );
      this.editUserFormGroup.controls['ThinkFolioUserId'].setValue(data.loadUserDetails.user.ThinkFolioUserId);

      if (data.loadUserDetails.user.ApiOnly) {
        this.editUserFormGroup.get('ApiOnly').enable();
        this.editUserFormGroup.get('IsFixServiceAccount').disable();
      } else if (data.loadUserDetails.user.IsFixServiceAccount) {
        this.editUserFormGroup.get('ApiOnly').disable();
        this.editUserFormGroup.get('IsFixServiceAccount').enable();
      } else {
        this.editUserFormGroup.get('ApiOnly').enable();
        this.editUserFormGroup.get('IsFixServiceAccount').enable();
      }

      this.initialUserModel = this.editUserFormGroup.value;

      this.containerId = data.loadUserDetails.user.Containers[0].Id;
      this.userId = data.loadUserDetails.user.Id;
      this.rowVersion = data.loadUserDetails.user.RowVersion;
      this.email = data.loadUserDetails.user.Email;
    }
  }

  public setOptions() {
    this.countryOptions = UserPoolService.getCountryOptions(this.Countries['countries']);

    this.userRolesOptions = UserPoolService.getUserRoleOptions(this.UserRoles);
    this.userRolesOptions.unshift({ label: '', value: '' });
  }

  public onRemoveGDPR() {
    this.sendUserId.emit(this.userId);
    this.store$.dispatch(new DeleteUserAction());
  }

  public onClose() {
    this.store$.dispatch(new CloseModalsAction());
  }

  public onErrorModalClose(): void {
    this.store$.dispatch(new ClearEditUserHttpErrorsAction());
  }

  public onResetPassword() {
    this.store$.dispatch(new ResetPasswordAction(this.userId, this.email));
  }

  public saveUser() {
    this.saveReady();

    this.store$.dispatch(new SaveEditedUserAction(this.containerId, this.userId, this.editUserFormGroup.value));
  }

  public saveReady() {
    this.editUserFormGroup.get('FirstName').setValue(this.editUserFormGroup.get('FirstName').value.trim());
    this.editUserFormGroup.get('LastName').setValue(this.editUserFormGroup.get('LastName').value.trim());
    this.editUserFormGroup.get('City').setValue(this.editUserFormGroup.get('City').value.trim());

    this.updateUser = this.editUserFormGroup.value;
    this.updateUser.UserId = this.userId;
    this.updateUser.ContainerId = this.containerId;
    this.updateUser.UserName = this.updateUser.Email;
    this.updateUser.RowVersion = this.rowVersion;
  }

  public isChecked(event, value: string) {
    const isChecked = event.target.checked;

    if (value === 'ApiOnly') {
      if (isChecked) {
        this.editUserFormGroup.get('IsFixServiceAccount').disable();
      } else {
        this.editUserFormGroup.get('IsFixServiceAccount').enable();
      }
    } else if (value === 'IsFixServiceAccount') {
      if (isChecked) {
        this.editUserFormGroup.get('ApiOnly').disable();
      } else {
        this.editUserFormGroup.get('ApiOnly').enable();
      }
    }
  }
}
